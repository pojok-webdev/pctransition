# npm-proxy

Use it as your registry and it'll work!
